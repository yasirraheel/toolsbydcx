ToolsByDcx AI Tools Access Suite
=================================

INSTALLATION INSTRUCTIONS:
--------------------------
1. Extract this ZIP file to a permanent folder on your computer.
2. Open Google Chrome (or Edge / Brave).
3. Type 'chrome://extensions' in the URL address bar and press Enter.
4. In the top right corner, turn ON 'Developer mode'.
5. Click 'Load unpacked' in the top left corner:
   - Select the 'ToolsByDcx-Extension-A' folder.
   - Click 'Load unpacked' again and select the 'ToolsByDcx-Companion-B' folder.
   (Both extensions are required for maximum security and cookie isolation).

6. IMPORTANT FOR GOOGLE FLOW USERS:
   - Double-click 'ToolsByDcx_Launcher.bat' to launch Chrome in an isolated profile.
   - This prevents any conflict with your personal Gmail accounts on Google Flow.
   - Log into https://toolsbydcx.com/ and launch your tools with 1-click!
